import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

export interface Message {
  id: number;
  conversationId: string;
  senderId: number;
  receiverId: number;
  content: string;
  createdAt: string;
  read: boolean;
}

export interface Conversation {
  id: string;
  participantId: number;
  participantName: string;
  participantImage: string;
  lastMessage?: string;
  lastMessageTime?: string;
  unreadCount: number;
}

interface ChatContextType {
  conversations: Conversation[];
  messages: Message[];
  unreadMessagesCount: number;
  getConversation: (userId: number) => Conversation | undefined;
  getMessages: (conversationId: string) => Message[];
  sendMessage: (receiverId: number, content: string) => void;
  markConversationAsRead: (conversationId: string) => void;
  createConversation: (userId: number, userName: string, userImage: string) => string;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);

  useEffect(() => {
    if (user) {
      // Load messages from localStorage
      const storedMessages = localStorage.getItem(`messages_${user.id}`);
      if (storedMessages) {
        setMessages(JSON.parse(storedMessages));
      }

      // Load conversations
      const storedConversations = localStorage.getItem(`conversations_${user.id}`);
      if (storedConversations) {
        setConversations(JSON.parse(storedConversations));
      }
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`messages_${user.id}`, JSON.stringify(messages));
      
      // Update conversations with latest message info
      updateConversations();
    }
  }, [messages, user]);

  const updateConversations = () => {
    if (!user) return;

    const updatedConversations = conversations.map(conv => {
      const convMessages = messages.filter(m => m.conversationId === conv.id);
      const unreadMessages = convMessages.filter(m => !m.read && m.senderId !== user.id);
      const lastMsg = convMessages.sort((a, b) => 
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      )[0];

      return {
        ...conv,
        lastMessage: lastMsg?.content,
        lastMessageTime: lastMsg?.createdAt,
        unreadCount: unreadMessages.length,
      };
    });

    setConversations(updatedConversations);
    localStorage.setItem(`conversations_${user.id}`, JSON.stringify(updatedConversations));
  };

  const createConversation = (userId: number, userName: string, userImage: string): string => {
    if (!user) return '';

    const conversationId = [user.id, userId].sort().join('_');
    
    // Check if conversation already exists
    const existing = conversations.find(c => c.id === conversationId);
    if (existing) return conversationId;

    const newConversation: Conversation = {
      id: conversationId,
      participantId: userId,
      participantName: userName,
      participantImage: userImage,
      unreadCount: 0,
    };

    const updated = [...conversations, newConversation];
    setConversations(updated);
    localStorage.setItem(`conversations_${user.id}`, JSON.stringify(updated));

    // Also create for the other user
    const otherUserConversations = JSON.parse(
      localStorage.getItem(`conversations_${userId}`) || '[]'
    );
    
    if (!otherUserConversations.find((c: Conversation) => c.id === conversationId)) {
      otherUserConversations.push({
        id: conversationId,
        participantId: user.id,
        participantName: user.name,
        participantImage: user.imgpath,
        unreadCount: 0,
      });
      localStorage.setItem(`conversations_${userId}`, JSON.stringify(otherUserConversations));
    }

    return conversationId;
  };

  const sendMessage = (receiverId: number, content: string) => {
    if (!user) return;

    const conversationId = [user.id, receiverId].sort().join('_');

    const newMessage: Message = {
      id: Date.now(),
      conversationId,
      senderId: user.id,
      receiverId,
      content,
      createdAt: new Date().toISOString(),
      read: false,
    };

    // Add to current user's messages
    const updatedMessages = [...messages, newMessage];
    setMessages(updatedMessages);

    // Add to receiver's messages
    const receiverMessages = JSON.parse(
      localStorage.getItem(`messages_${receiverId}`) || '[]'
    );
    receiverMessages.push(newMessage);
    localStorage.setItem(`messages_${receiverId}`, JSON.stringify(receiverMessages));

    // Update receiver's conversation unread count
    const receiverConversations = JSON.parse(
      localStorage.getItem(`conversations_${receiverId}`) || '[]'
    );
    const convIndex = receiverConversations.findIndex((c: Conversation) => c.id === conversationId);
    if (convIndex !== -1) {
      receiverConversations[convIndex].unreadCount += 1;
      receiverConversations[convIndex].lastMessage = content;
      receiverConversations[convIndex].lastMessageTime = newMessage.createdAt;
      localStorage.setItem(`conversations_${receiverId}`, JSON.stringify(receiverConversations));
    }
  };

  const markConversationAsRead = (conversationId: string) => {
    const updatedMessages = messages.map(m =>
      m.conversationId === conversationId && m.receiverId === user?.id
        ? { ...m, read: true }
        : m
    );
    setMessages(updatedMessages);
  };

  const getConversation = (userId: number): Conversation | undefined => {
    const conversationId = user ? [user.id, userId].sort().join('_') : '';
    return conversations.find(c => c.id === conversationId);
  };

  const getMessages = (conversationId: string): Message[] => {
    return messages
      .filter(m => m.conversationId === conversationId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  };

  const unreadMessagesCount = conversations.reduce((sum, conv) => sum + conv.unreadCount, 0);

  return (
    <ChatContext.Provider
      value={{
        conversations,
        messages,
        unreadMessagesCount,
        getConversation,
        getMessages,
        sendMessage,
        markConversationAsRead,
        createConversation,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}
