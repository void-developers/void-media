import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

export interface Notification {
  id: number;
  type: 'friend_request' | 'friend_accepted' | 'post_like';
  fromUserId: number;
  fromUserName: string;
  fromUserImage: string;
  message: string;
  createdAt: string;
  read: boolean;
}

export interface FriendRequest {
  id: number;
  fromUserId: number;
  toUserId: number;
  status: 'pending' | 'accepted' | 'rejected';
  createdAt: string;
}

interface SocialContextType {
  notifications: Notification[];
  friendRequests: FriendRequest[];
  friends: number[];
  unreadCount: number;
  sendFriendRequest: (toUserId: number, toUserName: string) => void;
  acceptFriendRequest: (requestId: number, fromUserId: number, fromUserName: string) => void;
  rejectFriendRequest: (requestId: number) => void;
  markNotificationAsRead: (notificationId: number) => void;
  markAllAsRead: () => void;
  isFriend: (userId: number) => boolean;
  hasPendingRequest: (userId: number) => boolean;
  removeFriend: (userId: number) => void;
}

const SocialContext = createContext<SocialContextType | undefined>(undefined);

export function SocialProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [friendRequests, setFriendRequests] = useState<FriendRequest[]>([]);
  const [friends, setFriends] = useState<number[]>([]);

  useEffect(() => {
    if (user) {
      // Load data from localStorage
      const storedNotifications = localStorage.getItem(`notifications_${user.id}`);
      const storedFriendRequests = localStorage.getItem(`friendRequests_${user.id}`);
      const storedFriends = localStorage.getItem(`friends_${user.id}`);

      if (storedNotifications) setNotifications(JSON.parse(storedNotifications));
      if (storedFriendRequests) setFriendRequests(JSON.parse(storedFriendRequests));
      if (storedFriends) setFriends(JSON.parse(storedFriends));
    }
  }, [user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`notifications_${user.id}`, JSON.stringify(notifications));
    }
  }, [notifications, user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`friendRequests_${user.id}`, JSON.stringify(friendRequests));
    }
  }, [friendRequests, user]);

  useEffect(() => {
    if (user) {
      localStorage.setItem(`friends_${user.id}`, JSON.stringify(friends));
    }
  }, [friends, user]);

  const sendFriendRequest = (toUserId: number, toUserName: string) => {
    if (!user) return;

    // Create friend request
    const newRequest: FriendRequest = {
      id: Date.now(),
      fromUserId: user.id,
      toUserId: toUserId,
      status: 'pending',
      createdAt: new Date().toISOString(),
    };

    // Save to recipient's friend requests
    const recipientRequests = JSON.parse(localStorage.getItem(`friendRequests_${toUserId}`) || '[]');
    recipientRequests.push(newRequest);
    localStorage.setItem(`friendRequests_${toUserId}`, JSON.stringify(recipientRequests));

    // Create notification for recipient
    const notification: Notification = {
      id: Date.now(),
      type: 'friend_request',
      fromUserId: user.id,
      fromUserName: user.name,
      fromUserImage: user.imgpath,
      message: `${user.name} sent you a friend request`,
      createdAt: new Date().toISOString(),
      read: false,
    };

    const recipientNotifications = JSON.parse(localStorage.getItem(`notifications_${toUserId}`) || '[]');
    recipientNotifications.unshift(notification);
    localStorage.setItem(`notifications_${toUserId}`, JSON.stringify(recipientNotifications));
  };

  const acceptFriendRequest = (requestId: number, fromUserId: number, fromUserName: string) => {
    if (!user) return;

    // Update friend request status
    const updatedRequests = friendRequests.map(req =>
      req.id === requestId ? { ...req, status: 'accepted' as const } : req
    );
    setFriendRequests(updatedRequests);

    // Add to friends list
    setFriends([...friends, fromUserId]);

    // Add current user to sender's friends list
    const senderFriends = JSON.parse(localStorage.getItem(`friends_${fromUserId}`) || '[]');
    senderFriends.push(user.id);
    localStorage.setItem(`friends_${fromUserId}`, JSON.stringify(senderFriends));

    // Create notification for sender
    const notification: Notification = {
      id: Date.now(),
      type: 'friend_accepted',
      fromUserId: user.id,
      fromUserName: user.name,
      fromUserImage: user.imgpath,
      message: `${user.name} accepted your friend request`,
      createdAt: new Date().toISOString(),
      read: false,
    };

    const senderNotifications = JSON.parse(localStorage.getItem(`notifications_${fromUserId}`) || '[]');
    senderNotifications.unshift(notification);
    localStorage.setItem(`notifications_${fromUserId}`, JSON.stringify(senderNotifications));
  };

  const rejectFriendRequest = (requestId: number) => {
    const updatedRequests = friendRequests.map(req =>
      req.id === requestId ? { ...req, status: 'rejected' as const } : req
    );
    setFriendRequests(updatedRequests);
  };

  const removeFriend = (userId: number) => {
    if (!user) return;

    // Remove from current user's friends
    setFriends(friends.filter(id => id !== userId));

    // Remove current user from their friends
    const theirFriends = JSON.parse(localStorage.getItem(`friends_${userId}`) || '[]');
    const updatedTheirFriends = theirFriends.filter((id: number) => id !== user.id);
    localStorage.setItem(`friends_${userId}`, JSON.stringify(updatedTheirFriends));
  };

  const markNotificationAsRead = (notificationId: number) => {
    setNotifications(notifications.map(notif =>
      notif.id === notificationId ? { ...notif, read: true } : notif
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(notif => ({ ...notif, read: true })));
  };

  const isFriend = (userId: number): boolean => {
    return friends.includes(userId);
  };

  const hasPendingRequest = (userId: number): boolean => {
    return friendRequests.some(req => 
      req.fromUserId === userId && req.status === 'pending'
    );
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <SocialContext.Provider
      value={{
        notifications,
        friendRequests,
        friends,
        unreadCount,
        sendFriendRequest,
        acceptFriendRequest,
        rejectFriendRequest,
        markNotificationAsRead,
        markAllAsRead,
        isFriend,
        hasPendingRequest,
        removeFriend,
      }}
    >
      {children}
    </SocialContext.Provider>
  );
}

export function useSocial() {
  const context = useContext(SocialContext);
  if (context === undefined) {
    throw new Error('useSocial must be used within a SocialProvider');
  }
  return context;
}
