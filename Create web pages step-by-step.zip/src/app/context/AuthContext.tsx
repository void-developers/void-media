import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: number;
  name: string;
  imgpath: string;
  description: string;
}

interface AuthContextType {
  user: User | null;
  login: (name: string, password: string) => Promise<boolean>;
  signup: (name: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (updates: Partial<User>) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem('user');
    return stored ? JSON.parse(stored) : null;
  });

  useEffect(() => {
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    } else {
      localStorage.removeItem('user');
    }
  }, [user]);

  const login = async (name: string, password: string): Promise<boolean> => {
    // Mock login - in real app, this would call your Flask backend
    // For demo purposes, we'll use localStorage to simulate a database
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find((u: any) => u.name === name && u.password === password);
    
    if (foundUser) {
      setUser({
        id: foundUser.id,
        name: foundUser.name,
        imgpath: foundUser.imgpath || 'default-profile-picture-avatar-photo-placeholder-vector-illustration-default-profile-picture-avatar-photo-placeholder-vector-189495158.webp',
        description: foundUser.description || ''
      });
      return true;
    }
    return false;
  };

  const signup = async (name: string, password: string): Promise<boolean> => {
    // Mock signup - in real app, this would call your Flask backend
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    
    // Check if user already exists
    if (users.find((u: any) => u.name === name)) {
      return false;
    }

    const newUser = {
      id: users.length + 1,
      name,
      password, // In real app, this would be hashed
      imgpath: 'default-profile-picture-avatar-photo-placeholder-vector-illustration-default-profile-picture-avatar-photo-placeholder-vector-189495158.webp',
      description: ''
    };

    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));
    
    setUser({
      id: newUser.id,
      name: newUser.name,
      imgpath: newUser.imgpath,
      description: newUser.description
    });
    
    return true;
  };

  const logout = () => {
    setUser(null);
  };

  const updateProfile = (updates: Partial<User>) => {
    if (user) {
      const updatedUser = { ...user, ...updates };
      setUser(updatedUser);
      
      // Update in localStorage users array
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const userIndex = users.findIndex((u: any) => u.id === user.id);
      if (userIndex !== -1) {
        users[userIndex] = { ...users[userIndex], ...updates };
        localStorage.setItem('users', JSON.stringify(users));
      }
    }
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
