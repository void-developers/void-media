import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { Input } from './ui/input';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from './ui/command';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Search } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SearchUser {
  id: number;
  name: string;
  imgpath: string;
  description: string;
}

export default function SearchBar() {
  const [open, setOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<SearchUser[]>([]);
  const navigate = useNavigate();
  const { user } = useAuth();

  useEffect(() => {
    if (searchQuery.trim()) {
      const users = JSON.parse(localStorage.getItem('users') || '[]');
      const filtered = users
        .filter((u: SearchUser) => 
          u.id !== user?.id && 
          u.name.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .slice(0, 5);
      setSearchResults(filtered);
    } else {
      setSearchResults([]);
    }
  }, [searchQuery, user]);

  const handleSelectUser = (userId: number) => {
    setOpen(false);
    setSearchQuery('');
    navigate(`/user/${userId}`);
  };

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search users..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setOpen(true);
            }}
            onFocus={() => setOpen(true)}
          />
        </div>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0" align="start">
        <Command>
          <CommandList>
            {searchResults.length > 0 ? (
              <CommandGroup heading="Users">
                {searchResults.map((result) => (
                  <CommandItem
                    key={result.id}
                    onSelect={() => handleSelectUser(result.id)}
                    className="cursor-pointer"
                  >
                    <div className="flex items-center gap-3 w-full">
                      <Avatar className="w-10 h-10">
                        {result.imgpath.startsWith('data:') || result.imgpath.startsWith('http') ? (
                          <AvatarImage src={result.imgpath} />
                        ) : null}
                        <AvatarFallback className="bg-gradient-to-br from-green-400 to-blue-500 text-white">
                          {result.name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium">{result.name}</p>
                        {result.description && (
                          <p className="text-sm text-muted-foreground truncate">
                            {result.description}
                          </p>
                        )}
                      </div>
                    </div>
                  </CommandItem>
                ))}
              </CommandGroup>
            ) : searchQuery.trim() ? (
              <CommandEmpty>No users found</CommandEmpty>
            ) : (
              <div className="p-4 text-center text-sm text-muted-foreground">
                Start typing to search users
              </div>
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}
