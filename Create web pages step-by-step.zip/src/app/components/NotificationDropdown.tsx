import { useSocial } from '../context/SocialContext';
import { useNavigate } from 'react-router';
import { Button } from './ui/button';
import { Bell } from 'lucide-react';

export default function NotificationDropdown() {
  const { unreadCount } = useSocial();
  const navigate = useNavigate();

  const handleClick = () => {
    navigate('/notifications');
  };

  return (
    <Button variant="ghost" size="icon" className="relative" onClick={handleClick}>
      <Bell className="w-5 h-5" />
      {unreadCount > 0 && (
        <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
          {unreadCount > 9 ? '9+' : unreadCount}
        </span>
      )}
    </Button>
  );
}