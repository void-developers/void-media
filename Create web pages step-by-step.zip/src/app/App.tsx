import { RouterProvider } from 'react-router';
import { AuthProvider } from './context/AuthContext';
import { SocialProvider } from './context/SocialContext';
import { ChatProvider } from './context/ChatContext';
import { router } from './routes';
import { Toaster } from './components/ui/sonner';

export default function App() {
  return (
    <AuthProvider>
      <SocialProvider>
        <ChatProvider>
          <RouterProvider router={router} />
          <Toaster />
        </ChatProvider>
      </SocialProvider>
    </AuthProvider>
  );
}