import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';
import { ArrowLeft, Check, X, Bell } from 'lucide-react';

export default function Notifications() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const {
    notifications,
    friendRequests,
    acceptFriendRequest,
    rejectFriendRequest,
    markNotificationAsRead,
    markAllAsRead,
  } = useSocial();

  useEffect(() => {
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  if (!user) {
    return null;
  }

  const pendingRequests = friendRequests.filter(req => req.status === 'pending');

  const handleAcceptRequest = (requestId: number, fromUserId: number, fromUserName: string) => {
    acceptFriendRequest(requestId, fromUserId, fromUserName);
    toast.success(`You are now friends with ${fromUserName}`);
  };

  const handleRejectRequest = (requestId: number) => {
    rejectFriendRequest(requestId);
    toast.success('Friend request rejected');
  };

  const handleNotificationClick = (notificationId: number, userId: number) => {
    markNotificationAsRead(notificationId);
    navigate(`/user/${userId}`);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <Button variant="ghost" onClick={() => navigate('/home')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Feed
          </Button>
          {(notifications.length > 0 || pendingRequests.length > 0) && (
            <Button variant="outline" onClick={markAllAsRead}>
              Mark All as Read
            </Button>
          )}
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 mt-8 space-y-6">
        {/* Friend Requests Table */}
        {pendingRequests.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Friend Requests ({pendingRequests.length})
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {pendingRequests.map((request) => {
                    const users = JSON.parse(localStorage.getItem('users') || '[]');
                    const fromUser = users.find((u: any) => u.id === request.fromUserId);
                    if (!fromUser) return null;

                    return (
                      <TableRow key={request.id} className="bg-blue-50">
                        <TableCell>
                          <Avatar className="w-10 h-10">
                            {fromUser.imgpath.startsWith('data:') || fromUser.imgpath.startsWith('http') ? (
                              <AvatarImage src={fromUser.imgpath} />
                            ) : null}
                            <AvatarFallback className="bg-gradient-to-br from-blue-400 to-indigo-500 text-white">
                              {fromUser.name.charAt(0).toUpperCase()}
                            </AvatarFallback>
                          </Avatar>
                        </TableCell>
                        <TableCell className="font-medium">{fromUser.name}</TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDate(request.createdAt)}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex gap-2 justify-end">
                            <Button
                              size="sm"
                              onClick={() => handleAcceptRequest(request.id, fromUser.id, fromUser.name)}
                            >
                              <Check className="w-4 h-4 mr-1" />
                              Accept
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleRejectRequest(request.id)}
                            >
                              <X className="w-4 h-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* All Notifications Table */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              All Notifications ({notifications.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {notifications.length === 0 && pendingRequests.length === 0 ? (
              <div className="py-12 text-center">
                <Bell className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-20" />
                <p className="text-muted-foreground">No notifications yet</p>
              </div>
            ) : notifications.length === 0 ? (
              <div className="py-8 text-center">
                <p className="text-muted-foreground">No other notifications</p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Message</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {notifications.map((notification) => (
                    <TableRow
                      key={notification.id}
                      className={`cursor-pointer hover:bg-gray-50 ${
                        !notification.read ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => handleNotificationClick(notification.id, notification.fromUserId)}
                    >
                      <TableCell>
                        <Avatar className="w-10 h-10">
                          {notification.fromUserImage.startsWith('data:') || notification.fromUserImage.startsWith('http') ? (
                            <AvatarImage src={notification.fromUserImage} />
                          ) : null}
                          <AvatarFallback className="bg-gradient-to-br from-purple-400 to-pink-500 text-white">
                            {notification.fromUserName.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                      </TableCell>
                      <TableCell className="font-medium">
                        {notification.fromUserName}
                      </TableCell>
                      <TableCell>{notification.message}</TableCell>
                      <TableCell>
                        <Badge variant={notification.type === 'friend_accepted' ? 'default' : 'secondary'}>
                          {notification.type === 'friend_request' && 'Friend Request'}
                          {notification.type === 'friend_accepted' && 'Friend Accepted'}
                          {notification.type === 'post_like' && 'Post Like'}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">
                        {formatDate(notification.createdAt)}
                      </TableCell>
                      <TableCell>
                        {!notification.read && (
                          <Badge variant="destructive">Unread</Badge>
                        )}
                        {notification.read && (
                          <Badge variant="outline">Read</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
