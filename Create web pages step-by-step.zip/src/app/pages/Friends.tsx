import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { useChat } from '../context/ChatContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader } from '../components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { ArrowLeft, UserMinus, MessageCircle } from 'lucide-react';
import { toast } from 'sonner';

interface FriendUser {
  id: number;
  name: string;
  imgpath: string;
  description: string;
}

export default function Friends() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { friends, removeFriend } = useSocial();
  const { createConversation } = useChat();
  const [friendsList, setFriendsList] = useState<FriendUser[]>([]);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    // Load friends data
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const friendsData = friends
      .map(friendId => users.find((u: any) => u.id === friendId))
      .filter(Boolean);
    setFriendsList(friendsData);
  }, [user, friends, navigate]);

  const handleRemoveFriend = (friendId: number, friendName: string) => {
    removeFriend(friendId);
    toast.success(`Removed ${friendName} from friends`);
  };

  const handleViewProfile = (friendId: number) => {
    navigate(`/user/${friendId}`);
  };

  const handleStartChat = (friend: FriendUser) => {
    createConversation(friend.id, friend.name, friend.imgpath);
    navigate(`/conversation/${friend.id}`);
  };

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => navigate('/home')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Feed
          </Button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 mt-8">
        <Card>
          <CardHeader>
            <h1 className="text-2xl font-semibold">Friends</h1>
            <p className="text-muted-foreground">
              {friendsList.length} {friendsList.length === 1 ? 'friend' : 'friends'}
            </p>
          </CardHeader>
          <CardContent>
            {friendsList.length === 0 ? (
              <div className="py-12 text-center">
                <p className="text-muted-foreground mb-4">You don't have any friends yet</p>
                <Button onClick={() => navigate('/home')}>
                  Find Friends
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                {friendsList.map((friend) => (
                  <div
                    key={friend.id}
                    className="flex items-center gap-4 p-4 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <Avatar
                      className="w-16 h-16 cursor-pointer"
                      onClick={() => handleViewProfile(friend.id)}
                    >
                      {friend.imgpath.startsWith('data:') || friend.imgpath.startsWith('http') ? (
                        <AvatarImage src={friend.imgpath} />
                      ) : null}
                      <AvatarFallback className="bg-gradient-to-br from-purple-400 to-pink-500 text-white text-xl">
                        {friend.name.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className="flex-1 min-w-0 cursor-pointer"
                      onClick={() => handleViewProfile(friend.id)}
                    >
                      <p className="font-medium text-lg">{friend.name}</p>
                      {friend.description && (
                        <p className="text-sm text-muted-foreground truncate">
                          {friend.description}
                        </p>
                      )}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => handleViewProfile(friend.id)}
                      >
                        View Profile
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleRemoveFriend(friend.id, friend.name)}
                      >
                        <UserMinus className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => handleStartChat(friend)}
                      >
                        <MessageCircle className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}