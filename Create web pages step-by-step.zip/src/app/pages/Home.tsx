import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { useChat } from '../context/ChatContext';
import { Button } from '../components/ui/button';
import { Textarea } from '../components/ui/textarea';
import { Card, CardContent, CardFooter, CardHeader } from '../components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import NotificationDropdown from '../components/NotificationDropdown';
import SearchBar from '../components/SearchBar';
import { toast } from 'sonner';
import { Send, User, LogOut, Users, MessageCircle } from 'lucide-react';

interface Post {
  id: number;
  userId: number;
  userName: string;
  userImage: string;
  content: string;
  createdAt: string;
}

export default function Home() {
  const { user, logout } = useAuth();
  const { friends } = useSocial();
  const { unreadMessagesCount } = useChat();
  const navigate = useNavigate();
  const [postContent, setPostContent] = useState('');
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    // Load posts from localStorage
    const storedPosts = localStorage.getItem('posts');
    if (storedPosts) {
      setPosts(JSON.parse(storedPosts));
    }
  }, [user, navigate]);

  if (!user) {
    return null;
  }

  const handleCreatePost = async () => {
    if (!postContent.trim()) {
      toast.error('Please write something to post');
      return;
    }

    setLoading(true);

    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));

    const newPost: Post = {
      id: Date.now(),
      userId: user.id,
      userName: user.name,
      userImage: user.imgpath,
      content: postContent,
      createdAt: new Date().toISOString(),
    };

    const updatedPosts = [newPost, ...posts];
    setPosts(updatedPosts);
    localStorage.setItem('posts', JSON.stringify(updatedPosts));

    setPostContent('');
    setLoading(false);
    toast.success('Post created successfully!');
  };

  const handleLogout = () => {
    logout();
    navigate('/');
    toast.success('Logged out successfully');
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined 
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm sticky top-0 z-10">
        <div className="max-w-3xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-full flex items-center justify-center text-white">
                <User className="w-5 h-5" />
              </div>
              <div>
                <h1 className="font-semibold">Social Feed</h1>
                <p className="text-sm text-muted-foreground">Welcome, {user.name}</p>
              </div>
            </div>
            
            <div className="flex-1 max-w-md hidden md:block">
              <SearchBar />
            </div>

            <div className="flex items-center space-x-2">
              <NotificationDropdown />
              <Button variant="ghost" size="icon" className="relative" onClick={() => navigate('/chat')}>
                <MessageCircle className="w-5 h-5" />
                {unreadMessagesCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                    {unreadMessagesCount > 9 ? '9+' : unreadMessagesCount}
                  </span>
                )}
              </Button>
              <Button variant="outline" onClick={() => navigate('/friends')}>
                <Users className="w-5 h-5 mr-2" />
                <span className="hidden sm:inline">Friends</span>
                {friends.length > 0 && (
                  <span className="ml-2 px-2 py-0.5 bg-indigo-100 text-indigo-700 rounded-full text-xs">
                    {friends.length}
                  </span>
                )}
              </Button>
              <Button variant="outline" onClick={() => navigate('/profile')}>
                Profile
              </Button>
              <Button variant="ghost" size="icon" onClick={handleLogout}>
                <LogOut className="w-5 h-5" />
              </Button>
            </div>
          </div>
          
          {/* Mobile Search */}
          <div className="mt-4 md:hidden">
            <SearchBar />
          </div>
        </div>
      </div>

      <div className="max-w-3xl mx-auto p-4 space-y-6">
        {/* Create Post Card */}
        <Card>
          <CardHeader>
            <div className="flex items-center space-x-3">
              <Avatar>
                {user.imgpath.startsWith('data:') || user.imgpath.startsWith('http') ? (
                  <AvatarImage src={user.imgpath} alt={user.name} />
                ) : null}
                <AvatarFallback className="bg-gradient-to-br from-indigo-400 to-purple-500 text-white">
                  {user.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div>
                <p className="font-medium">{user.name}</p>
                <p className="text-sm text-muted-foreground">What's on your mind?</p>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Share your thoughts..."
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              rows={3}
              disabled={loading}
              className="resize-none"
            />
          </CardContent>
          <CardFooter>
            <Button 
              onClick={handleCreatePost} 
              disabled={loading || !postContent.trim()}
              className="ml-auto"
            >
              <Send className="w-4 h-4 mr-2" />
              {loading ? 'Posting...' : 'Post'}
            </Button>
          </CardFooter>
        </Card>

        {/* Posts Feed */}
        <div className="space-y-4">
          {posts.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No posts yet. Be the first to share something!</p>
              </CardContent>
            </Card>
          ) : (
            posts.map((post) => (
              <Card key={post.id}>
                <CardHeader>
                  <div className="flex items-start space-x-3">
                    <Avatar>
                      {post.userImage.startsWith('data:') || post.userImage.startsWith('http') ? (
                        <AvatarImage src={post.userImage} alt={post.userName} />
                      ) : null}
                      <AvatarFallback className="bg-gradient-to-br from-blue-400 to-indigo-500 text-white">
                        {post.userName.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <p className="font-medium">{post.userName}</p>
                      <p className="text-sm text-muted-foreground">{formatDate(post.createdAt)}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="whitespace-pre-wrap">{post.content}</p>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}