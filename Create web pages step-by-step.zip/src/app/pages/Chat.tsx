import { useEffect } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { ArrowLeft, MessageCircle } from 'lucide-react';

export default function Chat() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { conversations } = useChat();

  useEffect(() => {
    if (!user) {
      navigate('/');
    }
  }, [user, navigate]);

  if (!user) {
    return null;
  }

  const sortedConversations = [...conversations].sort((a, b) => {
    if (!a.lastMessageTime) return 1;
    if (!b.lastMessageTime) return -1;
    return new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime();
  });

  const formatTime = (dateString?: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const hours = diff / (1000 * 60 * 60);

    if (hours < 24) {
      return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    } else if (hours < 48) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-100">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => navigate('/home')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Feed
          </Button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 mt-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageCircle className="w-5 h-5" />
              Messages
            </CardTitle>
          </CardHeader>
          <CardContent>
            {sortedConversations.length === 0 ? (
              <div className="py-12 text-center">
                <MessageCircle className="w-16 h-16 mx-auto mb-4 text-muted-foreground opacity-20" />
                <p className="text-muted-foreground mb-4">No conversations yet</p>
                <Button onClick={() => navigate('/friends')}>
                  Message a Friend
                </Button>
              </div>
            ) : (
              <div className="space-y-2">
                {sortedConversations.map((conversation) => (
                  <div
                    key={conversation.id}
                    className="flex items-center gap-4 p-4 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors border"
                    onClick={() => navigate(`/conversation/${conversation.participantId}`)}
                  >
                    <div className="relative">
                      <Avatar className="w-14 h-14">
                        {conversation.participantImage.startsWith('data:') || conversation.participantImage.startsWith('http') ? (
                          <AvatarImage src={conversation.participantImage} />
                        ) : null}
                        <AvatarFallback className="bg-gradient-to-br from-green-400 to-blue-500 text-white text-lg">
                          {conversation.participantName.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      {conversation.unreadCount > 0 && (
                        <div className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                          {conversation.unreadCount}
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <p className="font-semibold">{conversation.participantName}</p>
                        {conversation.lastMessageTime && (
                          <p className="text-xs text-muted-foreground">
                            {formatTime(conversation.lastMessageTime)}
                          </p>
                        )}
                      </div>
                      {conversation.lastMessage && (
                        <p className={`text-sm truncate ${
                          conversation.unreadCount > 0 ? 'font-medium text-gray-900' : 'text-muted-foreground'
                        }`}>
                          {conversation.lastMessage}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
