import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { useSocial } from '../context/SocialContext';
import { useChat } from '../context/ChatContext';
import { Button } from '../components/ui/button';
import { Card, CardContent, CardHeader } from '../components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { toast } from 'sonner';
import { ArrowLeft, UserPlus, UserMinus, MessageCircle } from 'lucide-react';

interface UserProfile {
  id: number;
  name: string;
  imgpath: string;
  description: string;
}

interface Post {
  id: number;
  userId: number;
  userName: string;
  userImage: string;
  content: string;
  createdAt: string;
}

export default function UserProfile() {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { sendFriendRequest, isFriend, hasPendingRequest, removeFriend } = useSocial();
  const { createConversation } = useChat();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [userPosts, setUserPosts] = useState<Post[]>([]);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    if (!userId) return;

    // Load user profile
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find((u: any) => u.id === parseInt(userId));
    
    if (foundUser) {
      setProfile({
        id: foundUser.id,
        name: foundUser.name,
        imgpath: foundUser.imgpath,
        description: foundUser.description || '',
      });

      // Load user's posts
      const allPosts = JSON.parse(localStorage.getItem('posts') || '[]');
      const filtered = allPosts.filter((p: Post) => p.userId === parseInt(userId));
      setUserPosts(filtered);
    }
  }, [userId, user, navigate]);

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>User not found</p>
      </div>
    );
  }

  const isAlreadyFriend = isFriend(profile.id);
  const hasPending = hasPendingRequest(profile.id);

  const handleAddFriend = () => {
    sendFriendRequest(profile.id, profile.name);
    toast.success(`Friend request sent to ${profile.name}`);
  };

  const handleRemoveFriend = () => {
    removeFriend(profile.id);
    toast.success(`Removed ${profile.name} from friends`);
  };

  const handleStartChat = () => {
    createConversation(profile.id, profile.name, profile.imgpath);
    navigate(`/conversation/${profile.id}`);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <Button variant="ghost" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-4 mt-8 space-y-6">
        {/* Profile Card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <Avatar className="w-32 h-32">
                {profile.imgpath.startsWith('data:') || profile.imgpath.startsWith('http') ? (
                  <AvatarImage src={profile.imgpath} />
                ) : null}
                <AvatarFallback className="bg-gradient-to-br from-indigo-400 to-purple-500 text-white text-4xl">
                  {profile.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>

              <div className="flex-1 text-center md:text-left">
                <h1 className="text-3xl font-semibold mb-2">{profile.name}</h1>
                <p className="text-muted-foreground mb-4">
                  {profile.description || 'No bio available'}
                </p>
                
                <div className="flex gap-2 justify-center md:justify-start">
                  {isAlreadyFriend ? (
                    <>
                      <Button onClick={handleStartChat}>
                        <MessageCircle className="w-4 h-4 mr-2" />
                        Message
                      </Button>
                      <Button variant="outline" onClick={handleRemoveFriend}>
                        <UserMinus className="w-4 h-4 mr-2" />
                        Remove Friend
                      </Button>
                    </>
                  ) : hasPending ? (
                    <Button disabled>
                      Request Pending
                    </Button>
                  ) : (
                    <Button onClick={handleAddFriend}>
                      <UserPlus className="w-4 h-4 mr-2" />
                      Add Friend
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Posts */}
        <div>
          <h2 className="text-xl font-semibold mb-4">Posts</h2>
          {userPosts.length === 0 ? (
            <Card>
              <CardContent className="py-12 text-center">
                <p className="text-muted-foreground">No posts yet</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {userPosts.map((post) => (
                <Card key={post.id}>
                  <CardHeader>
                    <div className="flex items-start space-x-3">
                      <Avatar>
                        {profile.imgpath.startsWith('data:') || profile.imgpath.startsWith('http') ? (
                          <AvatarImage src={profile.imgpath} />
                        ) : null}
                        <AvatarFallback className="bg-gradient-to-br from-blue-400 to-indigo-500 text-white">
                          {profile.name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <p className="font-medium">{profile.name}</p>
                        <p className="text-sm text-muted-foreground">{formatDate(post.createdAt)}</p>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="whitespace-pre-wrap">{post.content}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}