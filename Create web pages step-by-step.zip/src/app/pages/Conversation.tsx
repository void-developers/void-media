import { useEffect, useState, useRef } from 'react';
import { useNavigate, useParams } from 'react-router';
import { useAuth } from '../context/AuthContext';
import { useChat } from '../context/ChatContext';
import { useSocial } from '../context/SocialContext';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { toast } from 'sonner';
import { ArrowLeft, Send, Info } from 'lucide-react';

interface ChatUser {
  id: number;
  name: string;
  imgpath: string;
  description: string;
}

export default function Conversation() {
  const { userId } = useParams<{ userId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { isFriend } = useSocial();
  const { getMessages, sendMessage, markConversationAsRead, createConversation } = useChat();
  const [chatUser, setChatUser] = useState<ChatUser | null>(null);
  const [messageText, setMessageText] = useState('');
  const [conversationId, setConversationId] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!user) {
      navigate('/');
      return;
    }

    if (!userId) return;

    const parsedUserId = parseInt(userId);

    // Check if user is a friend
    if (!isFriend(parsedUserId)) {
      toast.error('You can only message friends');
      navigate('/friends');
      return;
    }

    // Load chat user info
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const foundUser = users.find((u: any) => u.id === parsedUserId);

    if (foundUser) {
      setChatUser({
        id: foundUser.id,
        name: foundUser.name,
        imgpath: foundUser.imgpath,
        description: foundUser.description || '',
      });

      // Create or get conversation
      const convId = createConversation(foundUser.id, foundUser.name, foundUser.imgpath);
      setConversationId(convId);

      // Mark conversation as read
      markConversationAsRead(convId);
    }
  }, [userId, user, navigate, isFriend, createConversation, markConversationAsRead]);

  useEffect(() => {
    // Scroll to bottom when messages change
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [conversationId]);

  if (!user || !chatUser) {
    return null;
  }

  const messages = getMessages(conversationId);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!messageText.trim()) return;

    sendMessage(chatUser.id, messageText);
    setMessageText('');
    
    // Scroll to bottom after sending
    setTimeout(() => {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDateSeparator = (dateString: string) => {
    const date = new Date(dateString);
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);

    if (date.toDateString() === today.toDateString()) {
      return 'Today';
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday';
    } else {
      return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    }
  };

  // Group messages by date
  const groupedMessages: { [key: string]: typeof messages } = {};
  messages.forEach(msg => {
    const dateKey = new Date(msg.createdAt).toDateString();
    if (!groupedMessages[dateKey]) {
      groupedMessages[dateKey] = [];
    }
    groupedMessages[dateKey].push(msg);
  });

  return (
    <div className="h-screen bg-gradient-to-br from-green-50 to-blue-100 flex flex-col">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate('/chat')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <Avatar className="w-10 h-10 cursor-pointer" onClick={() => navigate(`/user/${chatUser.id}`)}>
                {chatUser.imgpath.startsWith('data:') || chatUser.imgpath.startsWith('http') ? (
                  <AvatarImage src={chatUser.imgpath} />
                ) : null}
                <AvatarFallback className="bg-gradient-to-br from-green-400 to-blue-500 text-white">
                  {chatUser.name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="cursor-pointer" onClick={() => navigate(`/user/${chatUser.id}`)}>
                <p className="font-semibold">{chatUser.name}</p>
                <p className="text-xs text-muted-foreground">Click to view profile</p>
              </div>
            </div>
            <Button variant="ghost" size="icon" onClick={() => navigate(`/user/${chatUser.id}`)}>
              <Info className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          {Object.keys(groupedMessages).length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            Object.keys(groupedMessages).map(dateKey => (
              <div key={dateKey}>
                {/* Date Separator */}
                <div className="flex items-center justify-center my-4">
                  <div className="bg-white px-4 py-1 rounded-full shadow-sm text-xs text-muted-foreground">
                    {formatDateSeparator(dateKey)}
                  </div>
                </div>

                {/* Messages for this date */}
                {groupedMessages[dateKey].map((message) => {
                  const isSent = message.senderId === user.id;
                  return (
                    <div
                      key={message.id}
                      className={`flex items-end gap-2 mb-4 ${isSent ? 'flex-row-reverse' : 'flex-row'}`}
                    >
                      {!isSent && (
                        <Avatar className="w-8 h-8">
                          {chatUser.imgpath.startsWith('data:') || chatUser.imgpath.startsWith('http') ? (
                            <AvatarImage src={chatUser.imgpath} />
                          ) : null}
                          <AvatarFallback className="bg-gradient-to-br from-green-400 to-blue-500 text-white text-sm">
                            {chatUser.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                      )}
                      <div className={`flex flex-col ${isSent ? 'items-end' : 'items-start'} max-w-[70%]`}>
                        <div
                          className={`px-4 py-2 rounded-2xl ${
                            isSent
                              ? 'bg-blue-500 text-white rounded-br-sm'
                              : 'bg-white text-gray-900 rounded-bl-sm shadow-sm'
                          }`}
                        >
                          <p className="break-words">{message.content}</p>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1 px-2">
                          {formatTime(message.createdAt)}
                        </p>
                      </div>
                      {isSent && (
                        <Avatar className="w-8 h-8">
                          {user.imgpath.startsWith('data:') || user.imgpath.startsWith('http') ? (
                            <AvatarImage src={user.imgpath} />
                          ) : null}
                          <AvatarFallback className="bg-gradient-to-br from-indigo-400 to-purple-500 text-white text-sm">
                            {user.name.charAt(0).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                      )}
                    </div>
                  );
                })}
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Message Input */}
      <div className="bg-white border-t shadow-lg">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <form onSubmit={handleSendMessage} className="flex gap-2">
            <Input
              placeholder="Type a message..."
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              className="flex-1"
            />
            <Button type="submit" disabled={!messageText.trim()}>
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
