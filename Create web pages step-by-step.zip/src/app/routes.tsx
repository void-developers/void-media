import { createBrowserRouter } from "react-router";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Profile from "./pages/Profile";
import Home from "./pages/Home";
import UserProfile from "./pages/UserProfile";
import Friends from "./pages/Friends";
import Notifications from "./pages/Notifications";
import Chat from "./pages/Chat";
import Conversation from "./pages/Conversation";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/signup",
    Component: Signup,
  },
  {
    path: "/profile",
    Component: Profile,
  },
  {
    path: "/home",
    Component: Home,
  },
  {
    path: "/user/:userId",
    Component: UserProfile,
  },
  {
    path: "/friends",
    Component: Friends,
  },
  {
    path: "/notifications",
    Component: Notifications,
  },
  {
    path: "/chat",
    Component: Chat,
  },
  {
    path: "/conversation/:userId",
    Component: Conversation,
  },
]);