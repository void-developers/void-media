
  # Create web pages step-by-step

  This is a code bundle for Create web pages step-by-step. The original project is available at https://www.figma.com/design/hh9wXMdkvLqadU4FPgrg5Q/Create-web-pages-step-by-step.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  